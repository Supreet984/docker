package com.springboot.hdfc.docker;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	
	
	@GetMapping("/Welcome")
	public String getData() {
		return "<h1>hello  , welcome to docker image friends</h1>";
		
	}

}
